import 'package:flutter/material.dart';

class DaftarSitusScreen extends StatelessWidget {
  final List<Map<String, String>> daftarSitus = [
    {'title': 'Google', 'url': 'https://www.google.com'},
    {'title': 'YouTube', 'url': 'https://www.youtube.com'},
    {'title': 'Flutter', 'url': 'https://flutter.dev'},
    {'title': 'Stack Overflow', 'url': 'https://stackoverflow.com'},
    {'title': 'GitHub', 'url': 'https://github.com'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Daftar Situs Rekomendasi'),
      ),
      body: ListView.builder(
        itemCount: daftarSitus.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
            child: ListTile(
              contentPadding: EdgeInsets.all(10),
              title: Text(
                daftarSitus[index]['title']!,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              subtitle: Text(daftarSitus[index]['url']!),
              trailing: Icon(Icons.arrow_forward),
              onTap: () {
                // Navigate to the website or perform other actions
                _launchURL(daftarSitus[index]['url']!);
              },
            ),
          );
        },
      ),
    );
  }

  // Function to launch the URL in the browser
  void _launchURL(String url) {
    // You can use the url_launcher package for this
    // Example: launch(url);
    print('Opening URL: $url');
  }
}
