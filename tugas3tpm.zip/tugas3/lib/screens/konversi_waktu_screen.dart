import 'package:flutter/material.dart';

class KonversiWaktuScreen extends StatefulWidget {
  @override
  _KonversiWaktuScreenState createState() => _KonversiWaktuScreenState();
}

class _KonversiWaktuScreenState extends State<KonversiWaktuScreen> {
  final TextEditingController _tahunController = TextEditingController();
  String _hasilKonversi = '';

  void _konversiWaktu() {
    final tahun = int.tryParse(_tahunController.text);
    if (tahun != null) {
      final jam = tahun * 365 * 24;
      final menit = jam * 60;
      final detik = menit * 60;
      setState(() {
        _hasilKonversi = '$tahun Tahun = $jam Jam = $menit Menit = $detik Detik';
      });
    } else {
      setState(() {
        _hasilKonversi = 'Masukkan tahun yang valid';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Konversi Waktu')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _tahunController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: 'Masukkan Tahun'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _konversiWaktu,
              child: Text('Konversi'),
            ),
            SizedBox(height: 20),
            Text(_hasilKonversi, style: TextStyle(fontSize: 18)),
          ],
        ),
      ),
    );
  }
}
