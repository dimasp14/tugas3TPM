import 'package:flutter/material.dart';

class JenisBilanganScreen extends StatelessWidget {
  final List<String> bilangan = ['Prima', 'Desimal', 'Bulat Positif', 'Bulat Negatif', 'Cacah'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Jenis Bilangan')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView.builder(
          itemCount: bilangan.length,
          itemBuilder: (context, index) {
            return ListTile(
              title: Text(bilangan[index]),
              onTap: () {
                // Show description of each bilangan type
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: Text(bilangan[index]),
                    content: Text('Deskripsi tentang jenis bilangan ${bilangan[index]}'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(context), child: Text('Tutup'))
                    ],
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
