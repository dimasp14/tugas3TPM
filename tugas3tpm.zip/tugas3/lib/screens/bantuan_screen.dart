import 'package:flutter/material.dart';

class BantuanScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Bantuan')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Cara Penggunaan Aplikasi:',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16),
            Text(
              '1. Untuk menggunakan Stopwatch, pilih menu "Stopwatch" pada halaman utama.\n\n'
              '2. Pilih menu "Jenis Bilangan" untuk melihat informasi jenis bilangan (prima, cacah, dsb).\n\n'
              '3. Pilih menu "Tracking Lokasi" untuk melacak lokasi menggunakan LBS.\n\n'
              '4. Pilih menu "Konversi Waktu" untuk mengonversi tahun ke dalam jam, menit, dan detik.\n\n'
              '5. Pilih "Daftar Situs" untuk melihat daftar situs yang direkomendasikan.\n\n'
              '6. Favorit adalah untuk menyimpan situs favorit.',
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}
