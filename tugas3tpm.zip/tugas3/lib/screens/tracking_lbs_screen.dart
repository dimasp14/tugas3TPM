import 'package:flutter/material.dart';

class TrackingLBSScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Tracking LBS')),
      body: Center(
        child: Text('Tracking lokasi menggunakan LBS belum diimplementasikan'),
      ),
    );
  }
}
