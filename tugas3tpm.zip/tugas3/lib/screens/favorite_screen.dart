import 'package:flutter/material.dart';

class FavoriteScreen extends StatelessWidget {
  final List<Map<String, String>> favoriteSites = [
    {'title': 'Google', 'url': 'https://www.google.com'},
    {'title': 'Flutter', 'url': 'https://flutter.dev'},
    {'title': 'GitHub', 'url': 'https://github.com'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Favorit')),
      body: ListView.builder(
        itemCount: favoriteSites.length,
        itemBuilder: (context, index) {
          final site = favoriteSites[index];
          return ListTile(
            title: Text(site['title']!),
            onTap: () {
              // Open the URL in the default browser
              // You can use a package like `url_launcher` to open the URLs
            },
          );
        },
      ),
    );
  }
}
