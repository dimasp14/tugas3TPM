import 'package:flutter/material.dart';
import 'stopwatch_screen.dart';
import 'jenis_bilangan_screen.dart';
import 'tracking_lbs_screen.dart';
import 'konversi_waktu_screen.dart';
import 'daftar_situs_screen.dart';
import 'favorite_screen.dart';

class MenuScreen extends StatelessWidget {
  final List<Map<String, dynamic>> menuList = [
    {'title': 'Stopwatch', 'screen': StopwatchScreen()},
    {'title': 'Jenis Bilangan', 'screen': JenisBilanganScreen()},
    {'title': 'Tracking Lokasi', 'screen': TrackingLBSScreen()},
    {'title': 'Konversi Waktu', 'screen': KonversiWaktuScreen()},
    {'title': 'Daftar Situs', 'screen': DaftarSitusScreen()},
    {'title': 'Favorit', 'screen': FavoriteScreen()},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Beranda')),
      body: Center(
        child: ListView.builder(
          padding: const EdgeInsets.all(20),
          itemCount: menuList.length,
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  backgroundColor: Colors.blue, // Button color
                  textStyle: TextStyle(fontSize: 18), // Text styling
                ),
                child: Text(menuList[index]['title']),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => menuList[index]['screen']),
                  );
                },
              ),
            );
          },
        ),
      ),
    );
  }
}
