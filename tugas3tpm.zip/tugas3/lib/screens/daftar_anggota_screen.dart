import 'package:flutter/material.dart';

class DaftarAnggotaScreen extends StatelessWidget {
  final List<Map<String, String>> anggota = [
    {'nama': 'Nama 1', 'nim': 'NIM001'},
    {'nama': 'Nama 2', 'nim': 'NIM002'},
    {'nama': 'Nama 3', 'nim': 'NIM003'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Daftar Anggota')),
      body: ListView.builder(
        itemCount: anggota.length,
        itemBuilder: (context, index) {
          final a = anggota[index];
          return ListTile(
            title: Text(a['nama']!),
            subtitle: Text(a['nim']!),
          );
        },
      ),
    );
  }
}
